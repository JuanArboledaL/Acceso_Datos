package juanarboleda.apirest1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRest1Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiRest1Application.class, args);
    }

}
