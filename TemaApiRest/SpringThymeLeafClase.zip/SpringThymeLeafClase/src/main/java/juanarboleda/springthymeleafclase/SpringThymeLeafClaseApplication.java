package juanarboleda.springthymeleafclase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringThymeLeafClaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringThymeLeafClaseApplication.class, args);

    }

}
