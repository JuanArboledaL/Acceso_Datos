package org.example.apirest_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
