package org.example.apirest_thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestThymeleafApplication.class, args);
	}

}
