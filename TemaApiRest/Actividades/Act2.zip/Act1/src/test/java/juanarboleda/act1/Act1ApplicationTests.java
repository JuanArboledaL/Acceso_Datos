package juanarboleda.act1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Act1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
