package juanarboleda.act1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Act1Application {

    public static void main(String[] args) {
        SpringApplication.run(Act1Application.class, args);
    }

}
