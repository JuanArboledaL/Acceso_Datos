package juanarboleda.appbiblioteca2425.modelo.dao;

public interface IPrestamosDAO {
}
