package juanarboleda.appbiblioteca2425;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppBiblioteca2425Application {

    public static void main(String[] args) {
        SpringApplication.run(AppBiblioteca2425Application.class, args);
    }

}
