package juanarboleda.apirestfutbol2425thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestFutbol2425ThymeLeafApplicationTests {

    @Test
    void contextLoads() {
    }

}
