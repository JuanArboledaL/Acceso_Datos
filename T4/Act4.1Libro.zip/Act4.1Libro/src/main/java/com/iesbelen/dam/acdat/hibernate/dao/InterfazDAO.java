package com.iesbelen.dam.acdat.hibernate.dao;

public interface InterfazDAO {
    public void listar();
    public void actualizar(int id);
    public void insertar();
    public void eliminar(int id);
}
