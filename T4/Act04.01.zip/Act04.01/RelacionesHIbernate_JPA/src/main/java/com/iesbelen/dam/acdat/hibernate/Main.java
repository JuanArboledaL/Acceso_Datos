package com.iesbelen.dam.acdat.hibernate;

public class Main {
}