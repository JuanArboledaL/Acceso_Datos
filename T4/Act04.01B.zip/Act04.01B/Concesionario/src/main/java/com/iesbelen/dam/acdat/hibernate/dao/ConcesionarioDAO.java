package com.iesbelen.dam.acdat.hibernate.dao;

public class ConcesionarioDAO {
}
